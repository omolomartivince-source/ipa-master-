IPA MASTER Android V1 project.
applicationId: com.ipamaster.app
targetSdk: 36 (Android 16)
version: 1.0 / versionCode 1

Build with a cloud/Android environment:
./gradlew assembleDebug
./gradlew bundleRelease

Release builds must be signed before Google Play submission.
